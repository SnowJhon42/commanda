---
name: despliegue
description: Publicar COMANDA fase por fase en infraestructura gratuita para pruebas reales con usuarios. Usar cuando el usuario pida subir el proyecto a internet, configurar servicios cloud, mover a DB remota, cargar secrets, validar URLs publicas y dejar operacion minima estable.
---

# Despliegue COMANDA

## Objetivo
Llevar COMANDA de entorno local a entorno online de prueba, con backend, cliente, staff y base remota funcionando de punta a punta.

## Stack Recomendado (default gratis)
- Backend FastAPI: Render Web Service (Free)
- Front Cliente: Vercel (Free)
- Front Staff: Vercel (Free)
- Base de datos: Filess Postgres (si ya existe) o Neon Free como alternativa

## Fase 0 — Preflight local
1. Validar backend `8000`, cliente `5173`, staff `5174`.
2. Revisar logs de error y corregir arranque local antes de publicar.
3. Confirmar DB activa local y necesidad de migracion a Postgres remoto.

### Criterio de salida
- Todo local operativo.
- Sin errores bloqueantes de arranque.

## Fase 1 — Arquitectura y servicios
1. Definir mapa final de servicios y URLs.
2. Definir CORS esperado entre frontend y backend.
3. Confirmar estrategia de DB remota y almacenamiento de imagenes (R2).

### Criterio de salida
- Arquitectura cerrada sin decisiones pendientes.

## Fase 2 — Preparar deploy de backend
1. Asegurar start command cloud-compatible.
2. Confirmar dependencias de Postgres y carga de variables.
3. Definir variables obligatorias:
- `DATABASE_URL`
- `JWT_SECRET_KEY`
- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_R2_BUCKET`
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_PUBLIC_HOST`

### Criterio de salida
- Backend desplegable en Render sin usar SQLite local.

## Fase 3 — Base de datos remota
1. Conectar backend cloud a Postgres remota.
2. Aplicar esquema y datos minimos de prueba.
3. Validar lecturas y escrituras reales.

### Criterio de salida
- Endpoints criticos responden usando DB remota.

## Fase 4 — Deploy de fronts
1. Publicar `comanda-front-client`.
2. Publicar `comanda-front-staff`.
3. Configurar `NEXT_PUBLIC_API_URL` en ambos.
4. Verificar build y runtime.

### Criterio de salida
- Cliente y staff accesibles por URL publica.

## Fase 5 — Smoke tests end-to-end
1. `GET /health` backend publico -> 200.
2. Cliente carga menu.
3. Cliente crea pedido.
4. Staff visualiza y avanza estados.
5. Pago/cierre de mesa sin bloqueo.
6. Imagenes de productos visibles desde R2.

### Criterio de salida
- Flujo principal completo funcionando online.

## Fase 6 — Operacion minima y handoff
1. Documentar URLs finales.
2. Documentar secrets por plataforma.
3. Crear rutina de verificacion diaria.
4. Definir rollback simple (ultimo commit estable).
5. Dejar checklist para sesiones con testers.

### Criterio de salida
- Proyecto operable por el equipo sin improvisacion.

## Reglas de Ejecucion
- No cerrar fase con pendientes ambiguos.
- Cada fase debe terminar con evidencia verificable.
- Si una plataforma falla en free tier, escalar a alternativa gratuita sin frenar el objetivo.
- No exponer secretos en frontend ni repositorio.
- Si aparece decision de producto, escalar a `cto`.

## Relacion con Otros Agentes
- `arranque`: valida local y recupera entorno previo al deploy.
- `disene`: ajusta UX/UI antes de congelar release.
- `despliegue`: publica y deja online.
- `skill-creator`: solo para crear/editar skills, no para operar deploy.

## Criterio Final de Exito
- Backend, cliente y staff publicados con URLs publicas estables.
- DB remota activa y consistente.
- Flujo pedido -> staff -> cierre validado.
- Documentacion de operacion y rollback lista.
