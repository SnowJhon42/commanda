---
name: arranque
description: Levantar y recuperar el entorno local de COMANDA (backend 8000, cliente 5173, staff 5174) en Windows. Usar cuando el usuario pida "arrancar", "levantar puertos", "no conecta con servidor", "internal server error", revisar logs de arranque, o dejar todo operativo para demo/pruebas.
---

# Arranque COMANDA

## Objetivo
Dejar operativo el proyecto `C:\Users\agust\OneDrive\Desktop\COMANDA` con:
- Backend: `http://localhost:8000/health`
- Cliente: `http://localhost:5173`
- Staff: `http://localhost:5174`

## Flujo Base
1. Verificar estado actual.
```powershell
cd C:\Users\agust\OneDrive\Desktop\COMANDA
powershell -ExecutionPolicy Bypass -File .\scripts\comanda_local.ps1 status
```
2. Si hay inconsistencias, reiniciar stack completo.
```powershell
cd C:\Users\agust\OneDrive\Desktop\COMANDA
powershell -ExecutionPolicy Bypass -File .\scripts\comanda_local.ps1 restart
```
3. Validar endpoints en este orden:
```powershell
Invoke-WebRequest http://localhost:8000/health -UseBasicParsing
Invoke-WebRequest http://localhost:5173 -UseBasicParsing
Invoke-WebRequest http://localhost:5174 -UseBasicParsing
```

## Recuperacion Rapida
Si backend cae o cliente dice "No se pudo conectar con el servidor":
```powershell
cd C:\Users\agust\OneDrive\Desktop\COMANDA
powershell -ExecutionPolicy Bypass -File .\scripts\comanda_local.ps1 backend-up
Invoke-WebRequest http://localhost:8000/health -UseBasicParsing
```

Si cliente/staff quedan con `internal server error` o `spawn EPERM`:
1. Usar `restart` del script principal.
2. Si `5173` sigue inestable, forzar cliente en modo produccion:
```powershell
cd C:\Users\agust\OneDrive\Desktop\COMANDA\comanda-front-client
npm.cmd run build
npm.cmd run start -- -H 0.0.0.0 -p 5173
```
3. Revalidar `5173` y `5174`.

## Logs
Inspeccionar siempre estos archivos:
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\backend.err.log`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\backend.out.log`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\front-client.err.log`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\front-client.out.log`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\front-staff.err.log`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\logs\front-staff.out.log`

## Criterio de Cierre
Concluir solo cuando:
- `GET /health` en `8000` devuelve 200.
- Cliente `5173` devuelve 200.
- Staff `5174` devuelve 200.
- Se informa al usuario el estado final y, si aplica, el comando exacto para repetir mañana.

## Relacion con Otros Agentes
- `disene`: aplica cambios de UI/UX en frontend.
- `arranque`: valida que esos cambios se puedan probar operativamente.
- `skill-creator`: solo crea o edita skills; no se usa para levantar servicios.

Cuando termine `disene`, ejecutar este skill para confirmar entorno antes de demo o pruebas.
