---
name: disene
description: Disenar y redisenar pantallas de COMANDA con foco en experiencia moderna, artistica y practica para cliente y staff. Usar cuando se pidan mejoras de UI/UX, mobile-first, claridad de flujos, confianza visual en pagos/estados, o una experiencia mas premium sin perder simplicidad.
---

# Disene

## Objetivo
Entregar pantallas que sean:
- faciles de usar en segundos
- visualmente memorables
- confiables para acciones sensibles (pedido, estado, cobro)
- optimizadas primero para celular

## Alcance
Trabajar solo sobre:
- `C:\Users\agust\OneDrive\Desktop\COMANDA\comanda-front-client`
- `C:\Users\agust\OneDrive\Desktop\COMANDA\comanda-front-staff`

No tocar:
- backend, modelos, base de datos, endpoints
- scripts de arranque u operacion
- creacion/edicion de otros skills

Si se necesita API nueva o cambios de negocio, escalar a `cto`.

## Principios
- Priorizar tarea principal por pantalla.
- Evitar friccion: menos pasos, menos ruido, CTA principal dominante.
- Asegurar legibilidad y contraste.
- Usar recursos artisticos con moderacion: decoran, no distraen.
- Mantener consistencia entre cliente y staff.
- Reforzar seguridad percibida en estados, precios y pagos.

## Flujo de Trabajo
1. Auditar pantalla actual:
- accion principal
- accion secundaria
- bloqueo o confusion
- oportunidad visual
2. Definir direccion visual:
- estilo (sobrio/vibrante/artesanal)
- paleta con contraste real
- escala tipografica
- sistema de espaciado y componentes
3. Implementar cambios concretos en frontend:
- layout
- componentes
- estilos
- microcopy UI
4. Ajustar responsive:
- mobile-first (360-430px)
- tap targets minimos de 44px
- navegacion clara con una mano
5. Verificar:
- estados de carga/error/vacio/exito
- claridad de feedback al usuario
- coherencia visual global

## Handoff
- A `arranque`: rutas afectadas y que validar en `5173/5174`.
- A `cto`: resumen UX de cambios, riesgos y mejoras pendientes.

## Criterio de Cierre
- Pantalla mas simple de operar que antes.
- Jerarquia visual clara.
- Percepcion de seguridad y orden mejorada.
- Vista usable en mobile y desktop.
